package com.eams.dtobean;

public class EmployeeAssertDetails {

	private int assertId;
	private String assertName;
	private int quantity;
	private String empId;
	private String empName;
	private String phnNumber;
	private String allocationDate;
	
	public EmployeeAssertDetails() {
		
	}

	public EmployeeAssertDetails(int assertId, String assertName, int quantity, String empId, String empName,
			String phnNumber, String allocationDate) {
		super();
		this.assertId = assertId;
		this.assertName = assertName;
		this.quantity = quantity;
		this.empId = empId;
		this.empName = empName;
		this.phnNumber = phnNumber;
		this.allocationDate = allocationDate;
	}

	public EmployeeAssertDetails(String assertName, int quantity, String empId, String empName, String phnNumber) {
		super();
		this.assertName = assertName;
		this.quantity = quantity;
		this.empId = empId;
		this.empName = empName;
		this.phnNumber = phnNumber;
	}

	public int getAssertId() {
		return assertId;
	}

	public void setAssertId(int assertId) {
		this.assertId = assertId;
	}

	public String getAssertName() {
		return assertName;
	}

	public void setAssertName(String assertName) {
		this.assertName = assertName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getPhnNumber() {
		return phnNumber;
	}

	public void setPhnNumber(String phnNumber) {
		this.phnNumber = phnNumber;
	}

	public String getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(String allocationDate) {
		this.allocationDate = allocationDate;
	}

	@Override
	public String toString() {
		return "EmployeeAssertDetails [assertId=" + assertId + ", assertName=" + assertName + ", quantity=" + quantity
				+ ", empId=" + empId + ", empName=" + empName + ", phnNumber=" + phnNumber + ", allocationDate="
				+ allocationDate + "]";
	}
	
	
	
}
