package com.eams.exception;

public class EmployeeAssertException  extends Exception{

	public EmployeeAssertException() {
		
	}

	public EmployeeAssertException(String message) {
		super(message);
		
	}

	
}
