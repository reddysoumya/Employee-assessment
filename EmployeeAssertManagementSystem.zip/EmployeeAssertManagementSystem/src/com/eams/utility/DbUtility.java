package com.eams.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.eams.exception.EmployeeAssertException;

public class DbUtility {

	public static Connection getConnection() throws EmployeeAssertException {
		
		Connection con = null;
		try {
			
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg229", "training229");
			
		} catch (SQLException e) {
			throw new EmployeeAssertException("Connection Failure!!!!!!!" + e.getMessage());
		}
		return con;
	}
}
