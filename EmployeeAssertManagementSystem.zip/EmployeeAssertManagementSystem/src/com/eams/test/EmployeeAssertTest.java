package com.eams.test;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.eams.dao.EmployeeAssertDaoImpl;
import com.eams.dtobean.EmployeeAssertDetails;
import com.eams.exception.EmployeeAssertException;

import com.eams.utility.DbUtility;

public class EmployeeAssertTest {

	@Test
	public void databaseConnectionCheck() {
		DbUtility db = new DbUtility();
		Assert.assertNotNull(db);
	}
	
	/*@Test
	public void employeeAssertDetails() throws EmployeeAssertException {
		EmployeeAssertDetails ead = null;
		EmployeeAssertDaoImpl easi = new EmployeeAssertDaoImpl();
		ead = new EmployeeAssertDetails("Land", 1, "emp132", "UdayKiran", "9111000220");
		int actual = easi.insertEmployeeAssertDetails(ead);
		Assert.assertEquals(132, actual);
	}*/
	
	@Test
	public void getAllEmployeeAssertDetails() throws EmployeeAssertException {
		List<EmployeeAssertDetails> li = null;
		EmployeeAssertDaoImpl easi = new EmployeeAssertDaoImpl();
		li = easi.retireveAllEmployeeAssertDetails();
		Assert.assertNotNull(li);
	}
	
	@Test
	public void getEmployeeAssertDetailsBy() throws EmployeeAssertException {
		EmployeeAssertDetails ead = null;
		EmployeeAssertDaoImpl easi = new EmployeeAssertDaoImpl();
		ead = easi.employeeAssertDetailsById("emp130");
		Assert.assertNotNull(ead);
		
	}
}
