package com.eams.ui;

import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.eams.dtobean.EmployeeAssertDetails;
import com.eams.exception.EmployeeAssertException;
import com.eams.service.EmployeeAssertServiceImpl;
import com.eams.service.IEmployeeAssertService;
	
public class EmployeeAssertMain {

	static EmployeeAssertDetails employeeAssertDetails = null;
	static IEmployeeAssertService employeeAssertService = null;
	public static void main(String[] args)  {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("=====Employee and Assert Details=====");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("1.To enter employee details and assert details");
		System.out.println("2.To retrive all employee and corresponding assert details");
		System.out.println("3.To retrieve employee and assert details of a particular id");
		System.out.println("4.To exit");
		System.out.println("----------------------------------------------------------------------");
		System.out.println("Please enter any one option for above operations.");
		int option = scanner.nextInt();		
		Logger logger = Logger.getRootLogger();
		PropertyConfigurator.configure("resources/log4j.properties");
		
		switch(option) {
			case 1:
				employeeAssertService = new EmployeeAssertServiceImpl();
				boolean result;
				String assertName = null;
				String employeeId = null;
				String employeeName = null;
				String mobileNumber = null;
				int quantity = 0;
				//for entering assertName
				do {					
					System.out.println("Enter Assert Name: ");
					assertName = scanner.next();
				    result = employeeAssertService.validateAssertName(assertName);
				}while(result == false);
				//for EmployeeId
				do {					
					System.out.println("Enter Employee Id: ");
					employeeId = scanner.next();
				    result = employeeAssertService.validateEmpId(employeeId);
				}while(result == false);
				//for EmployeeName
				do {					
					System.out.println("Enter Employee Name: ");
					employeeName = scanner.next();
				    result =employeeAssertService.validateEmpName(employeeName);
				}while(result == false);
				//for Mobile Number
				do {					
					System.out.println("Enter Mobile Number: ");
					mobileNumber = scanner.next();
				    result = employeeAssertService.validateMobileNumber(mobileNumber);
				}while(result == false);
				//for quantity
				do {					
					System.out.println("Enter quantity: ");
					quantity = scanner.nextInt();
				    result = employeeAssertService.validateQuantity(quantity);
				}while(result == false);				
				
				employeeAssertDetails = new EmployeeAssertDetails(assertName, quantity, employeeId, employeeName, mobileNumber);
				
				int status = 0;
			try {
				status = storeEmployeeAssertDetails(employeeAssertDetails);
			} catch (EmployeeAssertException e) {
				logger.error("Exception" + e.getMessage());
				//System.out.println("Exception: " + e.getMessage());
			}
				if(status > 0) {
					logger.info("Assert is allocated for employee " + employeeName + " of Id " + employeeId + " and assert Id is: " + status);
					System.out.println("Assert is allocated for employee " + employeeName + " of Id " + employeeId + " and assert Id is: " + status);
				}
				else {
					logger.info("Details Not Inserted!!!!!!");
					System.out.println("Details Not Inserted!!!!!!");
				}
				break;
				
			case 2:				
				List<EmployeeAssertDetails> employeeAssertList = null;
				try {
					employeeAssertList = getAllEmployeeAssertDetails();
				} catch (EmployeeAssertException e) {
					logger.error("Exception: " + e.getMessage());
					System.out.println("Exception: " + e.getMessage());
				}
				
				for (EmployeeAssertDetails employeeAssertDetails1 : employeeAssertList) {
					System.out.println(employeeAssertDetails1);
				}				
				break;
				
			case 3:
				System.out.println("Enter Employee Id to fetch deatils: ");
				String eId = scanner.next();
				try {
					employeeAssertDetails = getEmployeeDetailsById(eId);
				} catch (EmployeeAssertException e) {
					logger.error("Exception: " + e.getMessage());
					System.out.println("Exception: " + e.getMessage());
				}				
				System.out.println(employeeAssertDetails);
				break;
			
			case 4:
				System.out.println("*****THANK YOU*****");
				System.exit(0);
				break;			
		
		}
	}	

	private static int storeEmployeeAssertDetails(EmployeeAssertDetails employeeAssertDetails1) throws EmployeeAssertException {		
		employeeAssertService = new EmployeeAssertServiceImpl();			
		return employeeAssertService.insertEmployeeAssertDetails(employeeAssertDetails1);
	}	

	private static List<EmployeeAssertDetails> getAllEmployeeAssertDetails() throws EmployeeAssertException {
		employeeAssertService = new EmployeeAssertServiceImpl();			
		return employeeAssertService.retrieveAllEmployeeAssertDetails();
	}
	
	private static EmployeeAssertDetails getEmployeeDetailsById(String eId) throws EmployeeAssertException {
		employeeAssertService = new EmployeeAssertServiceImpl();
		return employeeAssertService.employeeAssertDetailsById(eId);
	}

}
