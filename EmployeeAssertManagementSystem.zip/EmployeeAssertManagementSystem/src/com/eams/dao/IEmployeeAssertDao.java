package com.eams.dao;

import java.util.List;

import com.eams.dtobean.EmployeeAssertDetails;
import com.eams.exception.EmployeeAssertException;

public interface IEmployeeAssertDao {

	public int insertEmployeeAssertDetails(EmployeeAssertDetails employeeAssertDetails1) throws EmployeeAssertException;

	public List<EmployeeAssertDetails> retireveAllEmployeeAssertDetails() throws EmployeeAssertException;

	public EmployeeAssertDetails employeeAssertDetailsById(String eId) throws EmployeeAssertException;

}
