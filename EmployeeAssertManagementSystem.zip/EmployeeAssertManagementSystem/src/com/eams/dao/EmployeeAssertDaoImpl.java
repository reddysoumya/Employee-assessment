package com.eams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.eams.dtobean.EmployeeAssertDetails;
import com.eams.exception.EmployeeAssertException;
import com.eams.utility.DbUtility;

public class EmployeeAssertDaoImpl implements IEmployeeAssertDao{

	Connection connection = null;
	Logger logger = Logger.getRootLogger();	

	@Override
	public int insertEmployeeAssertDetails(EmployeeAssertDetails employeeAssertDetails1) throws EmployeeAssertException {
		PropertyConfigurator.configure("resources/log4j.properties");
		int output = 0;
		int assertId = 0;
		connection = DbUtility.getConnection();
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, employeeAssertDetails1.getAssertName());
			preparedStatement.setInt(2, employeeAssertDetails1.getQuantity());
			preparedStatement.setString(3, employeeAssertDetails1.getEmpId());
			preparedStatement.setString(4, employeeAssertDetails1.getEmpName());
			preparedStatement.setString(5, employeeAssertDetails1.getPhnNumber());
			output = preparedStatement.executeUpdate();
			
			PreparedStatement pst = connection.prepareStatement(IQueryMapper.ASSERTID_QUERY_SEQUENCE);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				 assertId = rs.getInt(1);
			}			
			
		} catch (SQLException e) {
			logger.error("Could't retrieve data from database!!!");
			throw new EmployeeAssertException("Unable to insert values into database!!! " + e.getMessage());
		}
		
		return assertId;
	}

	@Override
	public List<EmployeeAssertDetails> retireveAllEmployeeAssertDetails() throws EmployeeAssertException {
		PropertyConfigurator.configure("resources/log4j.properties");
		connection = DbUtility.getConnection();
		List<EmployeeAssertDetails> employeeAssertList = null;		
		 
		try {
			Statement st = connection.createStatement();
			EmployeeAssertDetails employeeAssertDetails2 = null;
			ResultSet rs = st.executeQuery(IQueryMapper.SELECT_QUERY);
			
			if(rs.next()) {
				employeeAssertList = new ArrayList<>();
				do {
					employeeAssertDetails2 = new EmployeeAssertDetails(rs.getInt(1), rs.getString(2),rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
					employeeAssertList.add(employeeAssertDetails2);
				}while(rs.next());
			}
		} catch (SQLException e) {
			logger.error("Could't retrieve data from database!!!");
			throw new EmployeeAssertException("Could't retrieve data from database!!!" + e.getMessage());
		}			
		return employeeAssertList;
	}

	@Override
	public EmployeeAssertDetails employeeAssertDetailsById(String eId) throws EmployeeAssertException {
		PropertyConfigurator.configure("resources/log4j.properties");
		connection = DbUtility.getConnection();
		EmployeeAssertDetails employeeAssertDetails3 = null;
		
		try {
			PreparedStatement pst = connection.prepareStatement(IQueryMapper.SELECT_BY_ID_QUERY);
			pst.setString(1, eId);
			ResultSet rs = pst.executeQuery();
			if(rs.next()) {
				employeeAssertDetails3 = new EmployeeAssertDetails(rs.getInt(1), rs.getString(2),rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
			}
		} catch (SQLException e) {
			logger.error("Could't retrieve data from database!!!");
			throw new EmployeeAssertException("Unable to fetch required employee details!!! " + e.getMessage());
		}		
		return employeeAssertDetails3;
	}

}
