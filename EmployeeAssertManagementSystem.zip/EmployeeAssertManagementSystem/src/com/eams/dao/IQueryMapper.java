package com.eams.dao;

public interface IQueryMapper {

	public static final String INSERT_QUERY = "INSERT INTO employeedetails VALUES(emp_sequence.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE)";
	public static final String ASSERTID_QUERY_SEQUENCE="SELECT emp_sequence.CURRVAL FROM DUAL";
	public static final String SELECT_QUERY = "SELECT *FROM employeedetails";
	public static final String SELECT_BY_ID_QUERY = "SELECT *FROM employeedetails WHERE empid = ?";
}
