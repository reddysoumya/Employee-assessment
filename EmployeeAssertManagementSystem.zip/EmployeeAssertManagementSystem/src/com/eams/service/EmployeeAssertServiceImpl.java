package com.eams.service;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.eams.dao.EmployeeAssertDaoImpl;
import com.eams.dao.IEmployeeAssertDao;
import com.eams.dtobean.EmployeeAssertDetails;
import com.eams.exception.EmployeeAssertException;

public class EmployeeAssertServiceImpl implements IEmployeeAssertService {
	
	static IEmployeeAssertDao employeeAssertDao = null;
	Logger logger = Logger.getRootLogger();
	@Override
	public boolean validateAssertName(String assertName) {		
			PropertyConfigurator.configure("resources/log4j.properties");
			Pattern pattern = Pattern.compile("{1}[A-Z][a-z]{1,15}");
			Matcher matcher = pattern.matcher(assertName);
			if(matcher.matches()) {				
				return true;
			}
			else {
				logger.info("Wrong Pattern for Assert Name");
				System.out.println("Enter correct assert Name!!!");
				return false;
			}			
	}
	
	@Override
	public boolean validateEmpId(String employeeId) {
			PropertyConfigurator.configure("resources/log4j.properties");
			Pattern pattern = Pattern.compile("{1}[eE]{1}[mM]{1}[pP][0-9]{3}");
		    Matcher matcher = pattern.matcher(employeeId);
		    if(matcher.matches()) {				
				return true;
			}
			else {
				logger.info("Wrong Pattern for Employee Id");
				System.out.println("Enter correct Employee Id!!!");
				return false;
			}	
	}	

	@Override
	public boolean validateEmpName(String employeeName) {
			PropertyConfigurator.configure("resources/log4j.properties");
			Pattern pattern = Pattern.compile("{1}[A-Z][a-z]{1,15}");
		    Matcher matcher = pattern.matcher(employeeName);
		    if(matcher.matches()) {				
				return true;
			}
			else {
				logger.info("Wrong Pattern for Employee Name");
				System.out.println("Enter correct Employee Name!!!");
				return false;
			}			
	}

	@Override
	public boolean validateMobileNumber(String mobileNumber) {
			PropertyConfigurator.configure("resources/log4j.properties");
			Pattern pattern = Pattern.compile("{1}[7-9][0-9]{9}");
		    Matcher matcher = pattern.matcher(mobileNumber);
		    if(matcher.matches()) {				
				return true;
			}
			else {
				logger.info("Wrong Pattern for Mobile Number");
				System.out.println("Enter correct Mobile Number!!!");
				return false;
			}		
	}

	@Override
	public boolean validateQuantity(int quantity) {		
		if(quantity == 1)
			return true;
		else {
			logger.info("Wrong quantity");
			System.out.println("Enter quantity as 1!!!");
			return false;
		}		
	}

	@Override
	public int insertEmployeeAssertDetails(EmployeeAssertDetails employeeAssertDetails1) throws EmployeeAssertException {
		employeeAssertDao = new EmployeeAssertDaoImpl();		
		return employeeAssertDao.insertEmployeeAssertDetails(employeeAssertDetails1);
	}

	@Override
	public List<EmployeeAssertDetails> retrieveAllEmployeeAssertDetails() throws EmployeeAssertException {
		employeeAssertDao = new EmployeeAssertDaoImpl();		
		return employeeAssertDao.retireveAllEmployeeAssertDetails();
	}

	@Override
	public EmployeeAssertDetails employeeAssertDetailsById(String eId) throws EmployeeAssertException {
		employeeAssertDao = new EmployeeAssertDaoImpl();	
		return employeeAssertDao.employeeAssertDetailsById(eId);
	}

}
