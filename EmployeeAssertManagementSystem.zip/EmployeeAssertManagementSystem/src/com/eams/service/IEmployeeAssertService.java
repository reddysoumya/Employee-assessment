package com.eams.service;

import java.util.List;

import com.eams.dtobean.EmployeeAssertDetails;
import com.eams.exception.EmployeeAssertException;

public interface IEmployeeAssertService {

	public boolean validateAssertName(String assertName);

	public boolean validateEmpId(String employeeId);

	public boolean validateEmpName(String employeeName);

	public boolean validateMobileNumber(String mobileNumber);

	public boolean validateQuantity(int quantity);

	public int insertEmployeeAssertDetails(EmployeeAssertDetails employeeAssertDetails1) throws EmployeeAssertException;

	public List<EmployeeAssertDetails> retrieveAllEmployeeAssertDetails() throws EmployeeAssertException;

	public EmployeeAssertDetails employeeAssertDetailsById(String eId) throws EmployeeAssertException;

}
